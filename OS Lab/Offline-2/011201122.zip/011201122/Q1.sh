#!/bin/bash

function sum_of_series()
{
	sum=0
	for (( i=1; i<=$1;i++ ))
	do
		sum=`expr $sum + $i`
	done
	return $sum
}


function main() {
	for (( ; ; ))
	do
		read input
		if [ $input -ge 0 ] 2>/dev/null; then
			sum_of_series $input
			echo "The sum is: $?"
			break
		else
			echo "Invalid Input! Please Try Again!"
		fi
	done
}

main
