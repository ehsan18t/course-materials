#!/bin/bash

function main () {
	doc=~/Documents
	empty=""
	result=`find / -type f -name $1 2>/dev/null`
	
	if [ $result -eq $empty ] 2>/dev/null; then
		result="$doc/$1"
		echo "dummy file" > "$result"
	fi
	echo $result
}

main $1
