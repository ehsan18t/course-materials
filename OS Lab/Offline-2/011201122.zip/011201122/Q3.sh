#!/bin/bash

function fib() {
	first=0
	second=1
	current=0

	echo -n "The Series: 0 1" # only for nice output
	
	if [ $1 -eq 0 ]; then
		return 0
	elif [ $1 -eq 1 ]; then
		return 1
	else
		for (( i=2; i<$1; i++ ))
		do
			current=`expr $first + $second`
			echo -n " $current"  # only for nice output
			first=$second
			second=$current
		done
		echo ""  # only for nice output
		return $current
	fi
}



function main() {
	n=$1
	fib $n
	echo "$1th fibonacci: $?"
}

main $1
