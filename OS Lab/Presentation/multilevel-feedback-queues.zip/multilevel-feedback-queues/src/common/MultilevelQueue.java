package common;

import scheduler.MultilevelFeedbackQueue;

import java.util.*;

public class MultilevelQueue {
    private final int queueCount;

    private final int agingTime;
    private final HashMap<Integer, PriorityQueue<Process>> readyQueue;
    private final HashMap<Integer, Integer> timeQuantum;
    private final PriorityQueue<Integer> sortedKeys;

    //////////////////////
    //    Constructor   //
    //////////////////////
    public MultilevelQueue(int queueCount, int agingTime) {
        this.queueCount = queueCount;
        this.agingTime = agingTime;
        this.sortedKeys = new PriorityQueue<>();
        this.readyQueue = new HashMap<>();
        this.timeQuantum = new HashMap<>();

        // init
        initQueue();
    }

    //////////////////
    //    Methods   //
    //////////////////
    private void initQueue() {
        // Manual User Input
        for (int i = 0; i < this.queueCount; i++) {
            System.out.print("Priority of Q" + i + " : ");
            int key = MultilevelFeedbackQueue.sc.nextInt();
            this.sortedKeys.add(key);

            System.out.print("Time Quantum of Q" + i + " : ");
            int time = MultilevelFeedbackQueue.sc.nextInt();
            this.timeQuantum.put(key, time);
        }

        // Creating Queues
        for (int key : this.sortedKeys) {
            // Round Robin
            PriorityQueue<Process> q = new PriorityQueue<>(Comparator.comparingInt(Process::getTimeSpent).reversed());
            this.readyQueue.put(key, q);
        }

        // Different rule for highest priority queue (FCFS)
//        PriorityQueue<Process> q = new PriorityQueue<>(Comparator.comparingInt(Process::getQueueArrive));
//        this.readyQueue.put(this.sortedKeys.peek(), q);
    }

    public void addProcess(Process p) {
        int priority = p.getNewPriority();
        if (this.readyQueue.containsKey(priority)) {
            this.readyQueue.get(priority).add(p);
        }
//        else {
        // this part added so that if a process with an unknown priority (doesn't have in readyQueue)
        // comes it will be handed over to the closest  queue to avoid system crash
        // THIS PART CAN BE IGNORED IF WE ARE GUARANTEED TO GET EXISTING PRIORITY PROCESS
//            int lastKey = 0;
//            for (int i : this.sortedKeys) {
//                lastKey = i;
//                if (priority < i) {
//                    p.setPriority(i);
//                    this.readyQueue.get(i).add(p);
//                    return;
//                }
//            }
//            p.setPriority(lastKey);
//            this.readyQueue.get(lastKey).add(p);
//        }
    }

    private Integer getTopKey() {
        // return the first queue key(priority) which is
        // not empty (checks from highest to lowest)
        Integer top = null;
        for (Integer i : this.sortedKeys) {
            if (!this.readyQueue.get(i).isEmpty()) {
                top = i;
                break;
            }
        }
        return top;
    }

    public void removeFromReady(Process p) {
        // if in ready, remove
        // else, search and remove
        if (!this.readyQueue.get(this.sortedKeys.peek()).remove(p)) {
            Integer top = getTopKey();
            if (top != null)
                this.readyQueue.get(top).remove(p);
        }
    }


    public Process getCurrentProcess() {
        // Returns the process that is supposed to execute
        Process p = null;
        Integer top = getTopKey();
        if (top != null) {
            p = this.readyQueue.get(top).peek();
        }
        return p;
    }

    private ArrayList<Integer> getSortedKeysCopy() {
        return new ArrayList<>(this.sortedKeys);
    }

    public void aging() {
        // Create a temporary stack to reverse the elements
        Stack<Integer> stack = new Stack<>();

        // Reverse keys to get the least important process
        for (int key : getSortedKeysCopy()) {
            stack.push(key);
        }

        // Aging starts here
        while (!stack.isEmpty()) {
            int key = stack.pop();
            // breaking out if no next queue. which means
            // we've moved all process that are eligible.
            if (!stack.isEmpty()) {
                int nextKey = stack.pop();
                PriorityQueue<Process> q = this.readyQueue.get(key);
                PriorityQueue<Process> nextQ = this.readyQueue.get(nextKey);
                for (Process p : q) {
                    // Since queue is sorted, if 1 failed
                    // rest will fail anyway, that's why break
                    if (this.agingTime <= p.getTimeSpent()) {
                        q.remove(p);
                        // reset queue entry time and priority before changing queue
                        p.setNewPriority(nextKey);
                        p.setQueueArrive();
                        nextQ.add(p);
                    } else
                        break;
                }

                // Super Important
                // else aging only run on last queue. Because all other keys
                // will be removed from our key stack.
                stack.push(nextKey);
                // The sequence of shifting will be like,
                // Q3 -> Q2
                // Q2 -> Q1
                // Q1 -> null (breaks)
            }
        }
    }

    ////////////////////////
    //    Getter-Setter   //
    ////////////////////////
    public boolean isNotEmpty() {
        return getTopKey() != null;
    }

    public int getTimeQuantum(int priority) {
        return this.timeQuantum.get(priority);
    }

    public void print() {
        for (int key: sortedKeys) {
            for (Process p: readyQueue.get(key))
                System.out.print("ID: " + p.getId() + " Key: " + key + " ");
        }
        System.out.println();
    }
}
