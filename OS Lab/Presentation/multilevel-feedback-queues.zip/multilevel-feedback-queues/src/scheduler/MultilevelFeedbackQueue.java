package scheduler;

import common.GlobalTimer;
import common.MultilevelQueue;
import common.Process;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class MultilevelFeedbackQueue {
    public static Scanner sc;
    public static GlobalTimer globalTimer = new GlobalTimer(0);
    static PriorityQueue<Process> processQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getArrivalTime));
    // Need manual init
    static MultilevelQueue readyQueue;

    // For Report
    static ArrayList<Process> procSeq = new ArrayList<>();
    static ArrayList<Process> gantt = new ArrayList<>();


    ///////////////////////
    //  Driver Functions //
    ///////////////////////
    public static void main(String[] args) {
        // =====================================================================
        // Input From File
        /*
         => Sample Input (with Descriptions)
            3           -> Queues Count
            8           -> Aging Time
            1 3         -> PRIORITY, TIME-QUANTUM
            2 5         -> PRIORITY, TIME-QUANTUM
            3 8         -> PRIORITY, TIME-QUANTUM
            3           -> Processes Count
            1 7 20 1    -> ID, AT, BT, PRIORITY of first process
            2 5 12 2    -> ID, AT, BT, PRIORITY of second process
            3 33 15 3    -> ID, AT, BT, PRIORITY of third process

        => Sample Input
            3
            8
            1 3
            2 5
            3 8
            3
            1 7 20 1
            2 5 12 2
            3 33 15 3
        */

        try {
            FileInputStream is = new FileInputStream("in.txt");
            System.setIn(is);
        } catch (Exception e) {
            System.err.println("Error Occurred.");
        }
        //======================================================================


        /////////////////
        // INPUT START //
        /////////////////
        sc = new Scanner(System.in);

        System.out.print("Number of Queue: ");
        int queueCount = sc.nextInt();
        System.out.print("Aging Time: ");
        int agingTime = sc.nextInt();
        System.out.println();

        // Init Ready Queue
        readyQueue = new MultilevelQueue(queueCount, agingTime);


        System.out.print("Number of total processes: ");
        int processCount = sc.nextInt();
        System.out.println();

        // Add Processes to processQueue
        System.out.println("////////////////////////");
        System.out.println("// Process Info Input //");
        System.out.println("////////////////////////");
        for (int i = 0; i < processCount; i++) {
            Process p = inputProcess(i, sc);
            processQueue.add(p);
        }
        System.out.println();

        ///////////////
        // INPUT END //
        ///////////////


        // Ideally it should be always true.
        // But for report generation I am
        // ending it when all inputted process
        // finishes execute.
        Process idle = new Process(-1, 0, 0, globalTimer);
        while (!processQueue.isEmpty() || readyQueue.isNotEmpty()) {
            addProcessToReadyQueue();

            if (readyQueue.isNotEmpty()) {
                // add if there are any idle time to gantt chart
                if (idle.getExecuted() > 0) {
                    gantt.add(idle.copy());
                    idle.setExecuted(0);
                }

                runProcessInCPU();
            }
            else {
                globalTimer.time++;
                idle.setExecuted(idle.getExecuted() + 1);
            }
        }

        // Report
        printReport();
    }


    ///////////////////////////////////
    //  Scheduling Related Functions //
    ///////////////////////////////////
    public static void addProcessToReadyQueue() {
        if (checkIfNewProcessArrived()) {
            while (!processQueue.isEmpty() && processQueue.peek().getArrivalTime() <= globalTimer.time) {
                Process p = processQueue.poll();
                if (p != null)
                    readyQueue.addProcess(p);
            }
        }
    }

    public static boolean checkIfNewProcessArrived() {
        if (!processQueue.isEmpty()) {
            return processQueue.peek().getArrivalTime() <= globalTimer.time;
        }
        return false;
    }


    public static void runProcessInCPU() {
        Process p = readyQueue.getCurrentProcess();

        if (p != null) {
            p.setExecuted(0);
            // time quantum for the resident queue
            int remExecution = readyQueue.getTimeQuantum(p.getNewPriority());
            while (!p.isDone() && remExecution-- > 0) {
                p.runProcess();
                readyQueue.aging();

                if (p.isDone()) {
                    // keeping for report gen
                    procSeq.add(p);
                    // removing from readyQueue if execution done
                    readyQueue.removeFromReady(p);
                }

                // Necessary to add new process in the ready queue
                // at right time
                addProcessToReadyQueue();

                // Update how much time executed
                p.setExecuted(p.getExecuted() + 1);
            }

            gantt.add(p.copy());
        }
    }


    ///////////////////////
    //  Others Functions //
    ///////////////////////
    public static Process inputProcess(int i, Scanner sc) {
        System.out.print(" - Process ID (" + i + "): ");
        int id = sc.nextInt();

        System.out.print(" - Arrival Time: ");
        int arrivalTime = sc.nextInt();

        System.out.print(" - Duration: ");
        int duration = sc.nextInt();

        System.out.print(" - Priority: ");
        int priority = sc.nextInt();
        System.out.println();

        return new Process(id, arrivalTime, duration, globalTimer, priority);
    }

    public static void printReport() {
        System.out.println("\n//////////////////////");
        System.out.println("// Execution Report //");
        System.out.println("//////////////////////");
        System.out.println("\n=> Gantt Chart: ");
        for (int i = 0; i < gantt.size(); i++) {
            System.out.print(gantt.get(i).getId() + "[" + gantt.get(i).getExecuted() + "]" + (i < gantt.size() - 1 ? " -> " : ""));
        }

        System.out.println();
        System.out.println("\n=> Detailed Report:");
        for (Process p : procSeq) {
            System.out.println("ID: " + p.getId() + "\tAT: " + p.getArrivalTime() + "\tBT: " + p.getDuration() +
                    "\tOriginal-Priority: " + p.getPriority() + "\tLast-Priority: " + p.getNewPriority() + "\t\tTAT: " +
                    (p.getCompletionTime() - p.getArrivalTime()) +
                    "\t WT: " + (p.getCompletionTime() - p.getArrivalTime() - p.getDuration()) + "\t RT: " +
                    p.getResponseTime() + "\t CT: " + p.getCompletionTime());
        }

        System.out.println();
        System.out.println("""
                => In this Implementation, all the queue is using Round Robin with their
                individual time quantum. But if a process starts executing, the execution will
                continue until the process or the time-quantum ended.
                
                => In the gantt chart, the representation format is as followed,
                PROCESS-ID [EXECUTION-TIME]
                EXAMPLE: 1[5] -> means process id 1 executed 5 unit.
                NOTE: ID -1 represents the idle time.
                """);
    }
}
