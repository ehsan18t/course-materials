package common;

import scheduler.MultilevelQueueSimulator;

import java.util.*;

public class MultilevelQueue {
    private final int queueCount;
    private final HashMap<Integer, PriorityQueue<Process>> readyQueue;
    private final PriorityQueue<Integer> sortedKeys;

    //////////////////////
    //    Constructor   //
    //////////////////////
    public MultilevelQueue(int queueCount) {
        this.queueCount = queueCount;
        this.sortedKeys = new PriorityQueue<>();
        this.readyQueue = new HashMap<>();

        // init
        initQueue();
    }

    //////////////////
    //    Methods   //
    //////////////////
    private void initQueue() {
        // Manual User Input
        for (int i = 0; i < this.queueCount; i++) {
            System.out.print("Priority of Q" + i + " : ");
            int key = MultilevelQueueSimulator.sc.nextInt();
            this.sortedKeys.add(key);
        }

        // Creating Queues
        for (int key : this.sortedKeys) {
            // FCFS
            PriorityQueue<Process> q = new PriorityQueue<>(Comparator.comparingInt(Process::getArrivalTime).reversed());
            this.readyQueue.put(key, q);
        }
    }

    public void addProcess(Process p) {
        int priority = p.getPriority();
        if (this.readyQueue.containsKey(priority)) {
            this.readyQueue.get(priority).add(p);
        }
    }

    private Integer getTopKey() {
        // return the first queue key(priority) which is
        // not empty (checks from highest to lowest)
        Integer top = null;
        for (Integer i : this.sortedKeys) {
            if (!this.readyQueue.get(i).isEmpty()) {
                top = i;
                break;
            }
        }
        return top;
    }

    public void removeFromReady(Process p) {
        // if in ready, remove
        // else, search and remove
        if (!this.readyQueue.get(this.sortedKeys.peek()).remove(p)) {
            Integer top = getTopKey();
            if (top != null)
                this.readyQueue.get(top).remove(p);
        }
    }


    public Process getCurrentProcess() {
        // Returns the process that is supposed to execute
        Process p = null;
        Integer top = getTopKey();
        if (top != null) {
            p = this.readyQueue.get(top).peek();
        }
        return p;
    }


    ////////////////////////
    //    Getter-Setter   //
    ////////////////////////
    public boolean isNotEmpty() {
        return getTopKey() != null;
    }
}
