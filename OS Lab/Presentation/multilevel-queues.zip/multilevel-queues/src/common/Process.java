package common;

public class Process {
    private final int id;
    private final int arrivalTime;
    private final int duration;
    private final GlobalTimer globalTimer;
    private int priority;
    private int queueArrive;
    private boolean gotCPU;
    private int responseTime;
    private int completionTime;
    private int executed;

    public Process(int id, int arrivalTime, int duration, GlobalTimer globalTimer) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.queueArrive = arrivalTime;
        this.duration = duration;
        this.globalTimer = globalTimer;
        this.gotCPU = false;
    }

    public Process(int id, int arrivalTime, int duration, GlobalTimer globalTimer, int priority) {
        this(id, arrivalTime, duration, globalTimer);
        this.priority = priority;
    }

    public void runProcess() {
        // Response Time
        if (!this.gotCPU) {
            this.gotCPU = true;
            responseTime = globalTimer.time;
        }

        globalTimer.time++;
        this.executed++;

        if (this.isDone())
            this.completionTime = globalTimer.time;
    }


    public boolean isDone() {
        return this.executed == this.duration;
    }

    public int getId() {
        return id;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public int getDuration() {
        return duration;
    }

    public int getPriority() {
        return priority;
    }

    public int getQueueArrive() {
        return queueArrive;
    }

    public void setQueueArrive(int time) {
        this.queueArrive = time;
    }

    public int getResponseTime() {
        return responseTime;
    }

    public int getCompletionTime() {
        return completionTime;
    }

    public int getExecuted() {
        return executed;
    }

    public void setExecuted(int executed) {
        this.executed = executed;
    }

    public Process copy() {
        Process p = new Process(id, arrivalTime, duration, globalTimer, priority);
        p.setExecuted(getExecuted());
        p.setQueueArrive(getQueueArrive());
        p.responseTime = responseTime;

        return p;
    }
}
