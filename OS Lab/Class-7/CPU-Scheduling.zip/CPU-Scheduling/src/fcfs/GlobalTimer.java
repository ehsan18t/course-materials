package fcfs;

public class GlobalTimer {
    public int time;

    public GlobalTimer(int time) {
        this.time = time;
    }
}
