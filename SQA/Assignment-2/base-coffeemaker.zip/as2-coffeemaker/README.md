# CoffeeMaker

Software engineers love caffeine, so we are planning to install a new coffee maker in the classroom. Fortunately, the CSC department at North Carolina State University (NCSU) has developed control software for a shiny new CoffeeMaker and has provided us with that code. We just have to test it.

You will be working with the JUnit testing framework to create unit test cases, find bugs, and
fix the CoffeeMaker code from NCSU’s OpenSeminar project repository (thanks to
the authors!). The example code comes with some seeded faults. 

The main interface (user input through the command line) is provided by the Main method in the Main class.
