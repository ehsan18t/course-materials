/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,css}", "./public/**/*.{html,css}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
